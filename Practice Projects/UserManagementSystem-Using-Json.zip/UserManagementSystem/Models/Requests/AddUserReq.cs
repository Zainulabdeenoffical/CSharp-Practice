﻿namespace UserManagementSystem.Models.Requests
{
    public class AddUserReq
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
    }
}
